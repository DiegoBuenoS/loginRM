/**
 * Serviço de API - Requisições HTTP
 * 
 * Este arquivo contém todas as funções para comunicação com a API TOTVS Identity.
 * Utiliza Axios para fazer requisições HTTP de forma centralizada.
 * 
 * @file Serviço de API
 * @author RM Login Team
 * @version 1.0.0
 */

import axios from 'axios';
import API_CONFIG from '../config/api.config';

// Criar instância do Axios com configurações padrão
const apiClient = axios.create({
  baseURL: API_CONFIG.BASE_URL,
  timeout: API_CONFIG.GENERAL.REQUEST_TIMEOUT,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
});

// Interceptor para adicionar token de autenticação às requisições
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor para tratar erros de resposta
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expirado - fazer logout
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

/**
 * Fazer login com credenciais de usuário
 * 
 * @param {string} username - Nome de usuário ou email
 * @param {string} password - Senha do usuário
 * @returns {Promise} Resposta da API com token de acesso
 */
export const loginUser = async (username, password) => {
  try {
    const params = new URLSearchParams();
    params.append('grant_type', API_CONFIG.OAUTH2.GRANT_TYPE);
    params.append('username', username);
    params.append('password', password);
    params.append('client_id', API_CONFIG.OAUTH2.CLIENT_ID);
    params.append('scope', API_CONFIG.OAUTH2.SCOPE);

    const response = await apiClient.post(API_CONFIG.AUTH.LOGIN, params);

    // Armazenar tokens no localStorage
    localStorage.setItem('access_token', response.data.access_token);
    if (response.data.refresh_token) {
      localStorage.setItem('refresh_token', response.data.refresh_token);
    }

    if (API_CONFIG.GENERAL.DEBUG) {
      console.log('Login bem-sucedido:', response.data);
    }

    return response.data;
  } catch (error) {
    if (API_CONFIG.GENERAL.DEBUG) {
      console.error('Erro ao fazer login:', error);
    }
    throw error;
  }
};

/**
 * Fazer logout do usuário
 * 
 * @returns {Promise} Resposta da API
 */
export const logoutUser = async () => {
  try {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (refreshToken) {
      const params = new URLSearchParams();
      params.append('token', refreshToken);
      params.append('client_id', API_CONFIG.OAUTH2.CLIENT_ID);

      await apiClient.post(API_CONFIG.AUTH.LOGOUT, params);
    }

    // Limpar tokens do localStorage
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');

    if (API_CONFIG.GENERAL.DEBUG) {
      console.log('Logout bem-sucedido');
    }

    return true;
  } catch (error) {
    if (API_CONFIG.GENERAL.DEBUG) {
      console.error('Erro ao fazer logout:', error);
    }
    // Mesmo se houver erro, limpar tokens locais
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    throw error;
  }
};

/**
 * Obter informações do usuário autenticado
 * 
 * @returns {Promise} Dados do usuário
 */
export const getUserInfo = async () => {
  try {
    const response = await apiClient.get(API_CONFIG.AUTH.USER_INFO);
    if (API_CONFIG.GENERAL.DEBUG) {
      console.log('Informações do usuário:', response.data);
    }
    return response.data;
  } catch (error) {
    if (API_CONFIG.GENERAL.DEBUG) {
      console.error('Erro ao obter informações do usuário:', error);
    }
    throw error;
  }
};

/**
 * Validar token de acesso
 * 
 * @param {string} token - Token a ser validado
 * @returns {Promise} Resultado da validação
 */
export const validateToken = async (token) => {
  try {
    const params = new URLSearchParams();
    params.append('token', token);
    params.append('client_id', API_CONFIG.OAUTH2.CLIENT_ID);

    const response = await apiClient.post(API_CONFIG.AUTH.VALIDATE_TOKEN, params);
    return response.data;
  } catch (error) {
    if (API_CONFIG.GENERAL.DEBUG) {
      console.error('Erro ao validar token:', error);
    }
    throw error;
  }
};

/**
 * Renovar token de acesso usando refresh token
 * 
 * @returns {Promise} Novo token de acesso
 */
export const refreshAccessToken = async () => {
  try {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (!refreshToken) {
      throw new Error('Refresh token não encontrado');
    }

    const params = new URLSearchParams();
    params.append('grant_type', 'refresh_token');
    params.append('refresh_token', refreshToken);
    params.append('client_id', API_CONFIG.OAUTH2.CLIENT_ID);

    const response = await apiClient.post(API_CONFIG.AUTH.REFRESH_TOKEN, params);

    // Atualizar tokens no localStorage
    localStorage.setItem('access_token', response.data.access_token);
    if (response.data.refresh_token) {
      localStorage.setItem('refresh_token', response.data.refresh_token);
    }

    if (API_CONFIG.GENERAL.DEBUG) {
      console.log('Token renovado com sucesso');
    }

    return response.data;
  } catch (error) {
    if (API_CONFIG.GENERAL.DEBUG) {
      console.error('Erro ao renovar token:', error);
    }
    // Se não conseguir renovar, fazer logout
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    throw error;
  }
};

export default apiClient;
