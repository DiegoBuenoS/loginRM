/**
 * Componente App Principal
 * 
 * Componente raiz da aplicação que gerencia o roteamento e layout geral.
 * 
 * @component
 * @author RM Login Team
 * @version 1.0.0
 */

import React from 'react';
import LoginPage from './pages/LoginPage';
import './index.css';

function App() {
  return (
    <div className="app">
      <LoginPage />
    </div>
  );
}

export default App;
