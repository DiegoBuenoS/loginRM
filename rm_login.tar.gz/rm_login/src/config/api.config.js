/**
 * Configuração de Endpoints da API TOTVS Identity
 * 
 * Este arquivo centraliza todas as URLs dos endpoints da API do TOTVS Identity.
 * Modifique os valores conforme necessário para seu ambiente.
 * 
 * @file Configuração de endpoints da API
 * @author RM Login Team
 * @version 1.0.0
 */

const API_CONFIG = {
  // URL base da API TOTVS Identity
  BASE_URL: process.env.REACT_APP_API_BASE_URL || 'https://identity.totvs.com.br',

  // Endpoints de autenticação
  AUTH: {
    // Endpoint para login
    LOGIN: '/api/oauth2/token',

    // Endpoint para refresh token
    REFRESH_TOKEN: '/api/oauth2/token',

    // Endpoint para logout
    LOGOUT: '/api/oauth2/revoke',

    // Endpoint para validar token
    VALIDATE_TOKEN: '/api/oauth2/introspect',

    // Endpoint para obter informações do usuário
    USER_INFO: '/api/oauth2/userinfo',
  },

  // Configurações de autenticação OAuth2
  OAUTH2: {
    // Client ID da aplicação (deve ser configurado no TOTVS Identity)
    CLIENT_ID: process.env.REACT_APP_OAUTH2_CLIENT_ID || 'seu_client_id_aqui',

    // Client Secret da aplicação (NUNCA deve ser exposto no frontend)
    CLIENT_SECRET: process.env.REACT_APP_OAUTH2_CLIENT_SECRET || '',

    // Tipo de concessão (grant type)
    GRANT_TYPE: 'password',

    // Escopo de permissões
    SCOPE: 'openid profile email',

    // URL de redirecionamento após login
    REDIRECT_URI: process.env.REACT_APP_REDIRECT_URI || 'http://localhost:5173/callback',

    // Tipo de resposta
    RESPONSE_TYPE: 'code',
  },

  // Configurações gerais
  GENERAL: {
    // Timeout padrão para requisições (em ms)
    REQUEST_TIMEOUT: 30000,

    // Ativar logs de debug
    DEBUG: process.env.NODE_ENV === 'development',

    // Versão da API
    API_VERSION: 'v1',
  },
};

export default API_CONFIG;
